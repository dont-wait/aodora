---
name: Haute Soie Heritage
colors:
  surface: '#fff8f5'
  surface-dim: '#e1d8d3'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf2ed'
  surface-container: '#f5ece7'
  surface-container-high: '#f0e6e1'
  surface-container-highest: '#eae1dc'
  on-surface: '#1f1b18'
  on-surface-variant: '#564242'
  inverse-surface: '#34302c'
  inverse-on-surface: '#f8efea'
  outline: '#897172'
  outline-variant: '#dcc0c0'
  surface-tint: '#a33b45'
  primary: '#5b0215'
  on-primary: '#ffffff'
  primary-container: '#7a1c29'
  on-primary-container: '#ff8990'
  inverse-primary: '#ffb3b5'
  secondary: '#775a19'
  on-secondary: '#ffffff'
  secondary-container: '#fed488'
  on-secondary-container: '#785a1a'
  tertiary: '#2c2a28'
  on-tertiary: '#ffffff'
  tertiary-container: '#42403d'
  on-tertiary-container: '#b0aba8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#ffb3b5'
  on-primary-fixed: '#40000c'
  on-primary-fixed-variant: '#83232f'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#e7e1dd'
  tertiary-fixed-dim: '#cbc5c2'
  on-tertiary-fixed: '#1d1b19'
  on-tertiary-fixed-variant: '#494644'
  background: '#fff8f5'
  on-background: '#1f1b18'
  surface-variant: '#eae1dc'
typography:
  display-hero:
    fontFamily: EB Garamond
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.01em
  display-hero-mobile:
    fontFamily: EB Garamond
    fontSize: 38px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: EB Garamond
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: 0em
  headline-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: 0em
  headline-md:
    fontFamily: EB Garamond
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: 0.01em
  headline-sm:
    fontFamily: EB Garamond
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: 0.01em
  title-editorial:
    fontFamily: EB Garamond
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: 0.03em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '300'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-uppercase:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.15em
  label-regular:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
spacing:
  gutter: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.25rem
  margin-tablet: 2.5rem
  margin-desktop: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

The design system embodies the understated luxury, poetic grace, and artisanal precision of traditional and modern Vietnamese Áo Dài craftsmanship. Drawing from the heritage of Vietnamese silk-weaving villages and contemporary haute couture, the aesthetic blends architectural editorial minimalism with tactile warmth. 

The emotional response should evoke reverent calm, timeless beauty, and bespoke craftsmanship. Every layout breathes intentionally, using expansive ivory space reminiscent of raw mulberry silk canvas. Interaction states are dignified, deliberate, and subtle. Architectural sharpness contrasts harmoniously with lyrical, calligraphic serifs and modern humanist typography to convey both cultural reverence and international atelier refinement.

## Colors

The palette draws inspiration from imperial lacquer, raw silkworm cocoons, gold embroidery thread, and hand-ground ink.

- **Primary (`#7A1C29` - Imperial Crimson):** A deep, resonant crimson derived from imperial Hue palace textiles and ceremonial Áo Dài. Used selectively for high-intent actions, primary interactive triggers, focal brand stamps, and elevated editorial highlights.
- **Secondary (`#C5A059` - Champagne Gold):** A delicate, low-sheen metallic thread hue. Used for subtle hairline borders, bespoke measurement badges, atelier crest accents, and fine dividing rules.
- **Tertiary (`#F5EFEB` - Raw Silk Cream):** The secondary background foundation. Applied to product detail cards, swatch containers, and inset editorial narrative blocks. The primary global surface canvas rests on `#FAF7F2` (Mulberry Silk Ivory).
- **Neutral (`#24201D` - Lacquer Ebony):** A warm, deep charcoal-black that provides contrast without the sterile harshness of true digital black. Used for high-legibility body copy, titles, and structural framing.

Subtle semantic variations utilize soft, muted tones: sage for in-stock statuses, ochre for custom tailoring waitlists, and soft terracotta for errors, maintaining harmony with the organic silk palette.

## Typography

The typographic scale pairs the lyrical, humanist Renaissance serifs of `EB Garamond` with the clean, legible geometry of `Plus Jakarta Sans`.

- **Headlines & Editorial Titles:** Set in `EB Garamond` with generous line-heights and natural tracking. It brings the presence of classical Vietnamese literature, high-fashion monographs, and atelier bespoke certificates.
- **Body & Captions:** Set in `Plus Jakarta Sans` at weights `300` and `400` to deliver effortless legibility across garment specifications, measurement guides, silk provenance essays, and ordering steps.
- **Labels, Badges, & Navigation Links:** Set in `Plus Jakarta Sans` in uppercase with wide tracking (`0.15em`) at small sizes, creating structured couture labeling reminiscent of garment tags and bespoke pattern markers.

## Layout & Spacing

The layout is grounded in a 12-column editorial grid for desktop and an adaptable 4-column system on mobile devices, characterized by deliberate negative space that allows silk silhouettes and draping imagery room to breathe.

- **Breakpoints:**
  - Mobile: `< 768px` (Margin: `1.25rem`, Gutter: `1.5rem`)
  - Tablet: `768px - 1024px` (Margin: `2.5rem`, Gutter: `2rem`)
  - Desktop: `> 1024px` (Max container: `1440px`, Margin: `4rem`, Gutter: `2.5rem`)

- **Rhythm & Alignment:**
  - Generous section padding (`4rem` to `6rem` vertical gap on desktop) maintains an unhurried, exhibition-style gallery pace.
  - Asymmetric pairings (e.g., a 7-column portrait image alongside a 5-column bespoke narrative block) reflect the graceful, flowing line of the Áo Dài flap (*tà áo*).

## Elevation & Depth

Visual hierarchy rejects exaggerated drop shadows in favor of atelier tactility, surface shifts, and gossamer-fine outlines.

- **Layered Silk Tiers:** Depth is established by placing lighter panels (`#FAF7F2`) over soft sand foundations (`#F5EFEB`), creating stacked, physical paper and fabric layers.
- **Low-Contrast Hairlines:** Modals, cards, dropdowns, and swatches employ ultra-crisp `1px` borders in Champagne Gold (`#C5A059` at 30% to 50% opacity) or warm parchment tone (`#E5DDCF`).
- **Ambient Lacquer Glaze:** For floating elements (drawers, sticky artisan tailoring menus, quick-view sheets), use an exceptionally subtle, diffuse warm shadow: `0 16px 36px -12px rgba(36, 32, 29, 0.08)`. Harsh directional shadows are strictly prohibited.

## Shapes

The shape system adopts absolute architectural precision with a roundedness value of `0` (0px sharp corners).

- All containers, product tiles, buttons, bespoke measurement input fields, and swatch selector tabs terminate in precise 90-degree right angles.
- This sharpness channels the discipline of pattern cutting, silk fabric bolts, traditional wooden printing blocks, and architectural Vietnamese courtyard framing.
- The sharpness of the UI geometry acts as an intentional structural counterpoint to the organic drape, curved collars, and soft movement of the silk garments.

## Components

### Buttons
- **Primary:** Sharp-edged rectangle filled with Imperial Crimson (`#7A1C29`), text in `#FAF7F2` (`label-uppercase`), padded with `0.875rem 2rem`. On hover, transitions subtly to `#62141F` with a gentle `0.2s ease` transition.
- **Secondary / Atelier Custom:** Transparent background with a `1px` solid border in `#C5A059`, text in `#24201D` (`label-uppercase`). Hover fills background with `#F5EFEB`.
- **Ghost:** Text-only in `#24201D` with an animated `1px` bottom border line in `#7A1C29` that expands from 0% to 100% width on hover.

### Product & Gallery Cards
- Crisp, unrounded edges with zero outer shadow.
- Image container features an off-white silk ground (`#F5EFEB`) with aspect ratio `3:4` or `2:3` for full-length Áo Dài garments.
- Garment details feature title in `headline-sm`, silk type in `body-sm` (`#7A726B`), and price in `title-editorial`.
- Delicate `1px` border appears either continuously or upon subtle hover framing.

### Swatches & Bespoke Options
- Fabric swatches are clean, square tiles with a `1px` border in `#E5DDCF`.
- Selected state activates a `1px` outer framing border in `#7A1C29` with an inner `2px` cream offset whitespace.
- Accompanied by silk weight identifiers (e.g., "16 Momme Mulberry Silk") in `label-uppercase`.

### Input Fields & Custom Sizing Selectors
- Flat surfaces (`#FAF7F2`) with an active base underline or clean `1px` border in `#C5A059` at 40% opacity.
- Focus state shifts border color to `#7A1C29` with crisp, zero-radius edges and no glow.
- Sizing measurement inputs include unit indicators (`cm` / `in`) in `label-regular` muted ebony.

### Badges & Status Chips
- Rectangular tags with `0.25rem 0.625rem` padding.
- Neutral states use `#F5EFEB` with `1px` border in `#C5A059`. Text in `label-uppercase`.
- Limited Heritage Editions use a solid `#7A1C29` fill with ivory lettering.

### Checkboxes & Radio Selectors
- Pure square frames (`0px` border radius) with `1px` border in `#24201D`.
- Checked state fills the interior with an inner solid square in `#7A1C29`.

### Atelier Measurement Sheet (Specialty Component)
- Segmented accordions bordered by hairline dividers in `#C5A059` (30% opacity).
- Collapsible sections for collar height (*cổ áo*), tunic length (*dài áo*), and wrist circumference, accompanied by delicate technical sketch overlays.